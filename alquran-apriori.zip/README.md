#Quran Text Mining with Apriori
- Stemming quran by topic (Indonesian translated)   
- Indexing by the most word use on each topic
- Generate quran topics itemsets and rules
- Compare similarity of book with 

#Acknowledgement
https://pypi.python.org/pypi/Sastrawi/1.0.1
https://github.com/timothyasp/apriori-python
Obo frequency similiarity
